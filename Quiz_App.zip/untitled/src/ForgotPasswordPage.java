import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class ForgotPasswordPage extends JFrame {
    JTextField newPasswordField;
    JTextField confirmPasswordField;
    JTextField Email1;

    ForgotPasswordPage() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 400);
        setLocation(400, 200);

        JLabel heading = new JLabel("Reset Password");
        heading.setBounds(200, 30, 200, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(heading);


        JLabel Email = new JLabel("Email");
        Email.setBounds(100, 50, 150, 30);
        add(Email);

        Email1 = new JTextField();
        Email1.setBounds(250, 50, 200, 30);
        add(Email1);

        JLabel newPasswordLabel = new JLabel("New Password:");
        newPasswordLabel.setBounds(100, 100, 150, 30);
        add(newPasswordLabel);

        newPasswordField = new JTextField();
        newPasswordField.setBounds(250, 100, 200, 30);
        add(newPasswordField);

        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(100, 150, 150, 30);
        add(confirmPasswordLabel);

        confirmPasswordField = new JTextField();
        confirmPasswordField.setBounds(250, 150, 200, 30);
        add(confirmPasswordField);

        JButton resetButton = new JButton("Reset");
        resetButton.setBounds(250, 200, 100, 30);
        add(resetButton);
        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String newPassword = newPasswordField.getText();
                String confirmPassword = confirmPasswordField.getText();
                String email = Email1.getText();

                if (newPassword.equals(confirmPassword)) {
                    // Connect to the database and update the password
                    Connection connection = null;
                    try {
                        // Set up the connection parameters
                        String url = "jdbc:mysql://localhost:3306/JDBC1";
                        String username = "root";
                        String password = "Chand@1990$%^";

                        // Connect to the database
                        try {
                            connection = DriverManager.getConnection(url, username, password);
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }

                        // Prepare the SQL statement
                        String sql = "UPDATE users SET password = ? WHERE email = ?";
                        PreparedStatement statement = connection.prepareStatement(sql);

                        // Set the parameter values
                        statement.setString(1, newPassword);
                        statement.setString(2, email);

                        // Execute the update
                        int rowsUpdated = statement.executeUpdate();

                        if (rowsUpdated > 0) {
                            JOptionPane.showMessageDialog(ForgotPasswordPage.this, "Password updated successfully", "Password Reset", JOptionPane.INFORMATION_MESSAGE);
                            // Open the login page and close the ForgotPasswordPage frame
                            new LoginPage();
                            dispose();
                        } else {
                            JOptionPane.showMessageDialog(ForgotPasswordPage.this, "Email not found", "Password Reset Error", JOptionPane.ERROR_MESSAGE);
                        }

                        // Close the statement
                        statement.close();
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    } finally {
                        // Close the connection
                        try {
                            if (connection != null) {
                                connection.close();
                            }
                        } catch (SQLException ex) {
                            ex.printStackTrace();
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(ForgotPasswordPage.this, "Passwords do not match", "Password Reset Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });


        resetButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String newPassword = newPasswordField.getText();
                String confirmPassword = confirmPasswordField.getText();
                // Perform password reset here
                // Update the database with the new password
                // Open the login page and close the ForgotPasswordFrame
                new LoginPage();
                dispose();

            }
        });
    }
}


