import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class ExamRandomCode extends JFrame {
    private JLabel timerLabel;
    private JLabel questionLabel;
    private JRadioButton option1RadioButton;
    private JRadioButton option2RadioButton;
    private JRadioButton option3RadioButton;
    private JRadioButton option4RadioButton;
    private ButtonGroup optionGroup;
    private JButton previousButton;
    private JButton nextButton;
    private JButton submitButton;
    private Timer timer;
    private int timeRemaining;
    private String quizCode;
    private int currentQuestionIndex;

    private String userName;
    private int score;

    private Connection connection;
    private PreparedStatement questionStatement;
    private PreparedStatement optionsStatement;
    private PreparedStatement scoreStatement;

    public ExamRandomCode(String userName, String code) {
        this.userName = userName;
        this.quizCode = code;

        setTitle("Exam");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(600, 400);

        timerLabel = new JLabel("Time: ");
        timerLabel.setBounds(10, 10, 100, 30);
        add(timerLabel);

        questionLabel = new JLabel("Question 1:");
        questionLabel.setBounds(10, 50, 500, 30);
        add(questionLabel);

        option1RadioButton = new JRadioButton("Option 1");
        option1RadioButton.setBounds(10, 90, 500, 30);
        add(option1RadioButton);

        option2RadioButton = new JRadioButton("Option 2");
        option2RadioButton.setBounds(10, 130, 500, 30);
        add(option2RadioButton);

        option3RadioButton = new JRadioButton("Option 3");
        option3RadioButton.setBounds(10, 170, 500, 30);
        add(option3RadioButton);

        option4RadioButton = new JRadioButton("Option 4");
        option4RadioButton.setBounds(10, 210, 500, 30);
        add(option4RadioButton);

        optionGroup = new ButtonGroup();
        optionGroup.add(option1RadioButton);
        optionGroup.add(option2RadioButton);
        optionGroup.add(option3RadioButton);
        optionGroup.add(option4RadioButton);

        previousButton = new JButton("Previous");
        previousButton.setBounds(10, 250, 100, 30);
        add(previousButton);

        nextButton = new JButton("Next");
        nextButton.setBounds(120, 250, 100, 30);
        add(nextButton);

        submitButton = new JButton("Submit");
        submitButton.setBounds(230, 250, 100, 30);
        add(submitButton);

        // Establish database connection
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/questionsdatabase", "root", "Chand@1990$%^");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Prepare statements for retrieving questions, options, and updating score
        prepareStatements();

        // Retrieve initial question and options
        currentQuestionIndex = 1;
        retrieveQuestion();

        timeRemaining = retrieveExpirationTime();

        timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateTime();
            }
        });
        timer.start();

        previousButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goToPreviousQuestion();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                goToNextQuestion();
            }
        });

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitQuiz();
            }
        });

        setVisible(true);
    }

    private void prepareStatements() {
        try {
         //   questionStatement = connection.prepareStatement("SELECT question FROM questions WHERE quiz_code = ? AND series_number = ?");
       //     optionsStatement = connection.prepareStatement("SELECT option1, option2, option3, option4 FROM options WHERE quiz_code = ? AND series_number = ?");
            scoreStatement = connection.prepareStatement("UPDATE scores SET score = ? WHERE user_name = ? AND quiz_code = ?");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void retrieveQuestion() {
        try {
            questionStatement.setString(1, quizCode);
            questionStatement.setInt(2, currentQuestionIndex);
            ResultSet questionResult = questionStatement.executeQuery();
            if (questionResult.next()) {
                String question = questionResult.getString("question");
                questionLabel.setText("Question " + currentQuestionIndex + ": " + question);
            }

            optionsStatement.setString(1, quizCode);
            optionsStatement.setInt(2, currentQuestionIndex);
            ResultSet optionsResult = optionsStatement.executeQuery();
            if (optionsResult.next()) {
                String option1 = optionsResult.getString("option1");
                String option2 = optionsResult.getString("option2");
                String option3 = optionsResult.getString("option3");
                String option4 = optionsResult.getString("option4");

                option1RadioButton.setText(option1);
                option2RadioButton.setText(option2);
                option3RadioButton.setText(option3);
                option4RadioButton.setText(option4);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private int retrieveExpirationTime() {
        // Retrieve expiration time for the quiz based on the quiz code
        // You need to implement this based on your database structure
        // Return the remaining time in seconds
        return 0;
    }

    private void updateTime() {
        timeRemaining--;

        if (timeRemaining <= 0) {
            timer.stop();
            submitQuiz();
        }

        int minutes = timeRemaining / 60;
        int seconds = timeRemaining % 60;

        String timeString = String.format("%02d:%02d", minutes, seconds);
        timerLabel.setText("Time: " + timeString);
    }

    private void goToPreviousQuestion() {
        if (currentQuestionIndex > 1) {
            currentQuestionIndex--;
            retrieveQuestion();
            nextButton.setEnabled(true);
            if (currentQuestionIndex == 1) {
                previousButton.setEnabled(false);
            }
        }
    }

    private void goToNextQuestion() {
        if (currentQuestionIndex < getMaxQuestionIndex()) {
            currentQuestionIndex++;
            retrieveQuestion();
            previousButton.setEnabled(true);
            if (currentQuestionIndex == getMaxQuestionIndex()) {
                nextButton.setEnabled(false);
            }
        }
    }

    private int getMaxQuestionIndex() {
        // Retrieve the maximum question index for the given quiz code
        // You need to implement this based on your database structure
        return 0;
    }

    private void submitQuiz() {
        // Calculate the score based on the selected options
        // You need to implement this based on your database structure and scoring logic

        // Update the score in the database
        updateScore();

        // Open a new frame to show the user's name and score
        showScoreFrame();

        // Close the current frame (ExamRandomCode)
        dispose();
    }

    private void updateScore() {
        // Update the score for the given user name and quiz code in the database
        // You need to implement this based on your database structure
    }

    private void showScoreFrame() {
        JFrame scoreFrame = new JFrame();
        scoreFrame.setTitle("Score");
        scoreFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        scoreFrame.setLayout(null);
        scoreFrame.setSize(400, 250);

        JLabel userNameLabel = new JLabel("User Name: " + userName);
        userNameLabel.setBounds(50, 50, 300, 30);
        scoreFrame.add(userNameLabel);

        JLabel scoreLabel = new JLabel("Score: " + score);
        scoreLabel.setBounds(50, 100, 300, 30);
        scoreFrame.add(scoreLabel);

        scoreFrame.setVisible(true);
    }

    // Main method for testing
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ExamRandomCode("John Doe", "123456");
            }
        });
    }
}
