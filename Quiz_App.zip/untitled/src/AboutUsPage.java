import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AboutUsPage extends JFrame {
    AboutUsPage() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 400);
        setLocation(400, 200);

        JLabel heading = new JLabel("About Us");
        heading.setBounds(220, 30, 150, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(heading);

        JLabel rulesLabel = new JLabel("<html><body style='width: 400px; text-align: justify;'>"
                + "Welcome to Simple Minds! We are a platform that aims to provide educational quizzes "
                + "to help you enhance your knowledge and skills. Our quizzes cover various topics and "
                + "are designed to be informative and engaging. Have fun exploring and learning with Simple Minds!"
                + "</body></html>");
        rulesLabel.setBounds(50, 80, 500, 200);
        rulesLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        add(rulesLabel);

        JButton backButton = new JButton("Back");
        backButton.setBounds(250, 300, 100, 30);
        add(backButton);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new HomePage1();

                dispose();
            }
        });
    }
}

