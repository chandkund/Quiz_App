import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

class PythonExamPage extends JFrame {
    private List<Question> questions;
    private int currentQuestionIndex;
    private int score;
    private int timeRemaining = 60;

    private JLabel questionLabel;
    private JRadioButton optionARadioButton;
    private JRadioButton optionBRadioButton;
    private JRadioButton optionCRadioButton;
    private JRadioButton optionDRadioButton;
    private JButton nextButton;
    private JButton previousButton;
    private JButton submitButton;
    private ButtonGroup optionButtonGroup;
    private JLabel timeLabel;

    PythonExamPage() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 600);
        setLocation(600, 300);

        questionLabel = new JLabel();
        questionLabel.setBounds(20, 30, 500, 30);
        add(questionLabel);

        optionARadioButton = new JRadioButton();
        optionARadioButton.setBounds(50, 80, 400, 30);
        add(optionARadioButton);

        optionBRadioButton = new JRadioButton();
        optionBRadioButton.setBounds(50, 120, 400, 30);
        add(optionBRadioButton);

        optionCRadioButton = new JRadioButton();
        optionCRadioButton.setBounds(50, 160, 400, 30);
        add(optionCRadioButton);

        optionDRadioButton = new JRadioButton();
        optionDRadioButton.setBounds(50, 200, 400, 30);
        add(optionDRadioButton);

        optionButtonGroup = new ButtonGroup();
        optionButtonGroup.add(optionARadioButton);
        optionButtonGroup.add(optionBRadioButton);
        optionButtonGroup.add(optionCRadioButton);
        optionButtonGroup.add(optionDRadioButton);

        previousButton = new JButton("Previous");
        previousButton.setBounds(100, 250, 100, 30);
        add(previousButton);

        nextButton = new JButton("Next");
        nextButton.setBounds(250, 250, 100, 30);
        add(nextButton);

        submitButton = new JButton("Submit");
        submitButton.setBounds(400, 250, 100, 30);
        add(submitButton);

        timeLabel = new JLabel("Time: 1:00");
        timeLabel.setBounds(450, 20, 100, 30);
        add(timeLabel);

        previousButton.addActionListener(e -> {
            recordUserAnswer();
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                showCurrentQuestion();
            }
        });

        nextButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                recordUserAnswer();
                if (currentQuestionIndex < questions.size() - 1) {
                    currentQuestionIndex++;
                    showCurrentQuestion();
                }
            }
        });

        submitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                recordUserAnswer();
                int totalQuestions = questions.size();

                // Display final score
                JOptionPane.showMessageDialog(null, "Your score: " + score + " out of " + totalQuestions);

                // Open the ReportCardPage
                dispose(); // Close the current frame
                new ReportCardPage(score); // Open the report card with the score
            }
        });

        loadQuestionsFromDatabase();
        currentQuestionIndex = 0;
        score = 0;
        showCurrentQuestion();
        startTimer();
    }

    private void loadQuestionsFromDatabase() {
        questions = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/JDBC1", "root", "Chand@1990$%^");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM questions");

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String question_text = resultSet.getString("question_text");
                String option_a = resultSet.getString("option_a");
                String option_b = resultSet.getString("option_b");
                String option_c = resultSet.getString("option_c");
                String option_d = resultSet.getString("option_d");
                String correct_answer = resultSet.getString("correct_answer");

                Question q = new Question(id, question_text, option_a, option_b, option_c, option_d, correct_answer);
                questions.add(q);
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showCurrentQuestion() {
        Question currentQuestion = questions.get(currentQuestionIndex);
        int totalQuestions = questions.size();

        questionLabel.setText("Question " + (currentQuestionIndex + 1) + " of " + totalQuestions + ": " + currentQuestion.getQuestion());
        optionARadioButton.setText("A. " + currentQuestion.getOptionA());
        optionBRadioButton.setText("B. " + currentQuestion.getOptionB());
        optionCRadioButton.setText("C. " + currentQuestion.getOptionC());
        optionDRadioButton.setText("D. " + currentQuestion.getOptionD());

        clearOptions();

        previousButton.setEnabled(currentQuestionIndex != 0);

        if (currentQuestionIndex == totalQuestions - 1) {
            nextButton.setEnabled(false);
            submitButton.setEnabled(true);
        } else {
            nextButton.setEnabled(true);
            submitButton.setEnabled(false);
        }
    }

    private void clearOptions() {
        optionButtonGroup.clearSelection();
    }

    private void recordUserAnswer() {
        Question currentQuestion = questions.get(currentQuestionIndex);
        String userAnswer = "";

        if (optionARadioButton.isSelected()) {
            userAnswer = "A";
        } else if (optionBRadioButton.isSelected()) {
            userAnswer = "B";
        } else if (optionCRadioButton.isSelected()) {
            userAnswer = "C";
        } else if (optionDRadioButton.isSelected()) {
            userAnswer = "D";
        }

        if (userAnswer.equals(currentQuestion.getCorrectAnswer())) {
            score++;
        }
    }

    private void startTimer() {
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timeRemaining--;
                int minutes = timeRemaining / 60;
                int seconds = timeRemaining % 60;
                timeLabel.setText(String.format("Time: %d:%02d", minutes, seconds));

                if (timeRemaining <= 0) {
                    ((Timer) e.getSource()).stop();
                    submitButton.doClick(); // Automatically click the Submit button when time runs out
                }
            }
        });
        timer.start();
    }
}

class Question {
    private final int id;
    private final String question;
    private final String optionA;
    private final String optionB;
    private final String optionC;
    private final String optionD;
    private final String correctAnswer;

    Question(int id, String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer) {
        this.id = id;
        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctAnswer = correctAnswer;
    }

    int getId() {
        return id;
    }

    String getQuestion() {
        return question;
    }

    String getOptionA() {
        return optionA;
    }

    String getOptionB() {
        return optionB;
    }

    String getOptionC() {
        return optionC;
    }

    String getOptionD() {
        return optionD;
    }

    String getCorrectAnswer() {
        return correctAnswer;
    }
}

