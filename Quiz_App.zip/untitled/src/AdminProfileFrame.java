import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminProfileFrame extends JFrame {
    public AdminProfileFrame() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 400);
        setLocation(400, 200);

        JButton homeButton = new JButton("Home");
        homeButton.setBounds(10, 10, 100, 30);
        add(homeButton);

        JButton aboutUsButton = new JButton("About Us");
        aboutUsButton.setBounds(120, 10, 100, 30);
        add(aboutUsButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(470, 10, 100, 30);
        add(logoutButton);

        JButton addQuestionButton = new JButton("Add Question");
        addQuestionButton.setBounds(200, 100, 200, 30);
        add(addQuestionButton);

        JButton removeQuestionButton = new JButton("Remove Question");
        removeQuestionButton.setBounds(200, 150, 200, 30);
        add(removeQuestionButton);

        JButton viewReportsButton = new JButton("View Reports");
        viewReportsButton.setBounds(200, 200, 200, 30);
        add(viewReportsButton);

        homeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HomePage1();
                dispose();
            }
        });

        aboutUsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AboutUsPage();
                dispose();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int choice = JOptionPane.showConfirmDialog(AdminProfileFrame.this,
                        "Are you sure you want to log out?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    new AdminLoginPage();
                    dispose(); // Close the admin profile frame
                }
            }
        });

        addQuestionButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        new AddQuestionFrame();
                    }
                });
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AdminProfileFrame();
            }
        });
    }
}
