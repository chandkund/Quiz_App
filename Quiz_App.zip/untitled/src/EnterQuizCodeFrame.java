import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EnterQuizCodeFrame extends JFrame {
    private JTextField userNameField;
    private JTextField enterCodeField;
    private JTextField subjectField;

    public EnterQuizCodeFrame() {
        setTitle("Enter Quiz Code");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(400, 250);

        JLabel userNameLabel = new JLabel("User Name:");
        userNameLabel.setBounds(50, 50, 100, 30);
        add(userNameLabel);

        userNameField = new JTextField();
        userNameField.setBounds(150, 50, 200, 30);
        add(userNameField);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setBounds(50, 90, 100, 30);
        add(subjectLabel);

        subjectField = new JTextField();
        subjectField.setBounds(150, 90, 200, 30);
        add(subjectField);

        JLabel enterCodeLabel = new JLabel("Enter Quiz Code:");
        enterCodeLabel.setBounds(50, 130, 100, 30);
        add(enterCodeLabel);

        enterCodeField = new JTextField();
        enterCodeField.setBounds(150, 130, 200, 30);
        add(enterCodeField);

        JButton startButton = new JButton("Start");
        startButton.setBounds(150, 170, 100, 30);
        add(startButton);

        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startQuiz();
            }
        });

        setVisible(true);
    }

    private void startQuiz() {
        String userName = userNameField.getText();
        String quizCode = enterCodeField.getText();
        String subject = subjectField.getText();

        if (checkQuizCode(quizCode, subject)) {
            new QuizFrame(userName, quizCode, subject);
            dispose();
        } else {
            JOptionPane.showMessageDialog(null, "Invalid quiz code. Please try again.");
        }
    }

    private boolean checkQuizCode(String quizCode, String subject) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/questionsdatabase", "root", "Chand@1990$%^");
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + subject + " WHERE generatedCode = ?");
            statement.setString(1, quizCode);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return true;
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new EnterQuizCodeFrame();
            }
        });
    }
}

class QuizFrame extends JFrame {
    private List<AnotherQuestion> questions;
    private int currentQuestionIndex;
    private String userName;

    private int score;
    private int timeRemaining = 60;

    private final JLabel questionLabel;
    private final JRadioButton optionARadioButton;
    private final JRadioButton optionBRadioButton;
    private final JRadioButton optionCRadioButton;
    private final JRadioButton optionDRadioButton;
    private final JButton nextButton;
    private final JButton previousButton;
    private final JButton submitButton;
    public final ButtonGroup optionButtonGroup;
    private final JLabel timeLabel;



    public QuizFrame(String userName, String quizCode, String subject) {
        this.userName=userName;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 600);
        setLocation(600, 300);

        questionLabel = new JLabel();
        questionLabel.setBounds(20, 30, 500, 30);
        add(questionLabel);

        optionARadioButton = new JRadioButton();
        optionARadioButton.setBounds(50, 80, 400, 30);
        add(optionARadioButton);

        optionBRadioButton = new JRadioButton();
        optionBRadioButton.setBounds(50, 120, 400, 30);
        add(optionBRadioButton);

        optionCRadioButton = new JRadioButton();
        optionCRadioButton.setBounds(50, 160, 400, 30);
        add(optionCRadioButton);

        optionDRadioButton = new JRadioButton();
        optionDRadioButton.setBounds(50, 200, 400, 30);
        add(optionDRadioButton);

        optionButtonGroup = new ButtonGroup();
         optionButtonGroup.add(optionARadioButton);
       optionButtonGroup.add(optionBRadioButton);
        optionButtonGroup.add(optionCRadioButton);
       optionButtonGroup.add(optionDRadioButton);


        nextButton = new JButton("Next");
        nextButton.setBounds(200, 250, 80, 30);
        add(nextButton);

        previousButton = new JButton("Previous");
        previousButton.setBounds(100, 250, 100, 30);
        previousButton.setEnabled(false);
        add(previousButton);

        submitButton = new JButton("Submit");
        submitButton.setBounds(320, 250, 80, 30);
        add(submitButton);

        timeLabel = new JLabel();
        timeLabel.setBounds(500, 10, 80, 20);
        add(timeLabel);

        loadQuestionsFromDatabase(quizCode, subject);

        currentQuestionIndex = 0;
        showQuestion();




        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentQuestionIndex < questions.size() - 1) {
                    currentQuestionIndex++;
                    showQuestion();
                    previousButton.setEnabled(true);
                }
            }
        });

        previousButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentQuestionIndex > 0) {
                    currentQuestionIndex--;
                    showQuestion();
                }
            }
        });

        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitQuiz(userName);
            }
        });

        startTimer();
    }

    private void loadQuestionsFromDatabase(String quizCode, String subject) {
        questions = new ArrayList<>();

        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/questionsdatabase", "root", "Chand@1990$%^");
            PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + subject + " WHERE generatedCode = ?");
            statement.setString(1, quizCode);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
               // int id = resultSet.getInt("id");
                String questionText = resultSet.getString("question");
                String optionA = resultSet.getString("option1");
                String optionB = resultSet.getString("option2");
                String optionC = resultSet.getString("option3");
                String optionD = resultSet.getString("option4");
                String correctAnswer = resultSet.getString("correctAnswer");

                AnotherQuestion question = new AnotherQuestion(questionText, optionA, optionB, optionC, optionD, correctAnswer);
                questions.add(question);
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showQuestion() {
        AnotherQuestion currentQuestion = questions.get(currentQuestionIndex);
        questionLabel.setText(currentQuestion.getQuestion());
        optionARadioButton.setText(currentQuestion.getOptionA());
        optionBRadioButton.setText(currentQuestion.getOptionB());
        optionCRadioButton.setText(currentQuestion.getOptionC());
        optionDRadioButton.setText(currentQuestion.getOptionD());
        resetOptions();
        updateButtonStates();
    }

    private void resetOptions() {
        optionARadioButton.setSelected(false);
        optionBRadioButton.setSelected(false);
        optionCRadioButton.setSelected(false);
        optionDRadioButton.setSelected(false);
    }

    private void updateButtonStates() {
        if (currentQuestionIndex == 0) {
            previousButton.setEnabled(false);
        } else {
            previousButton.setEnabled(true);
        }

        if (currentQuestionIndex == questions.size() - 1) {
            nextButton.setEnabled(false);
        } else {
            nextButton.setEnabled(true);
        }
    }

    private void submitQuiz(String userName) {
        int score = calculateScore();
        String reportCard = "Name: " + userName + "\nScore: " + score;

        // Display the report card in a new frame
        JFrame reportCardFrame = new JFrame();
        JTextArea reportCardTextArea = new JTextArea(reportCard);
        reportCardTextArea.setEditable(false);
        reportCardFrame.getContentPane().add(reportCardTextArea);
        reportCardFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        reportCardFrame.setSize(400, 200);
        reportCardFrame.setVisible(true);

        // Close the current frame (JavaExamPage)
        dispose();
    }

    private int calculateScore() {
        int score = 0;

        for (AnotherQuestion question : questions) {
            String selectedAnswer = getSelectedAnswer(question);

            if (selectedAnswer != null && selectedAnswer.equals(question.getCorrectOption())) {
                score++;
            }
        }

        return score;
    }

    private String getSelectedAnswer(AnotherQuestion question) {
        if (optionARadioButton.isSelected()) {
            return question.getOptionA();
        } else if (optionBRadioButton.isSelected()) {
            return question.getOptionB();
        } else if (optionCRadioButton.isSelected()) {
            return question.getOptionC();
        } else if (optionDRadioButton.isSelected()) {
            return question.getOptionD();
        }

        return null;
    }

    private void startTimer() {
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                timeRemaining--;
                timeLabel.setText("Time: " + timeRemaining + "s");

                if (timeRemaining <= 0) {
                    ((Timer) e.getSource()).stop();
                    submitQuiz(userName);
                }
            }
        });

        timer.start();
    }
}


class AnotherQuestion {
    private final String question;
    private final String optionA;
    private final String optionB;
    private final String optionC;
    private final String optionD;
    private final String correctOption;

    public AnotherQuestion( String question, String optionA, String optionB, String optionC, String optionD, String correctOption) {
        this.question = question;
        this.optionA = optionA;
        this.optionB = optionB;
        this.optionC = optionC;
        this.optionD = optionD;
        this.correctOption = correctOption;
    }

    public String getQuestion() {
        return question;
    }

    public String getOptionA() {
        return optionA;
    }

    public String getOptionB() {
        return optionB;
    }

    public String getOptionC() {
        return optionC;
    }

    public String getOptionD() {
        return optionD;
    }

    public String getCorrectOption() {
        return correctOption;
    }
}
