import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PrivacyPolicyFrame extends JFrame {
    PrivacyPolicyFrame() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(800, 600);
        setLocation(400, 200);

        JLabel heading = new JLabel("Privacy Policy");
        heading.setBounds(300, 30, 200, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(heading);

        JLabel rulesLabel = new JLabel("<html><body style='width: 600px; text-align: justify;'>"
                + "Respecting your privacy is critically important to achieving our mission of motivating every student. These are our guiding privacy principles:"
                + "<br><br>"
                + "We don’t ask you for personal information unless we truly need it.<br>"
                + "We don’t keep your personal information longer than is necessary to provide our services to you.<br>"
                + "We don’t share your personal information with anyone except to comply with the law, provide our services, or protect our rights.<br>"
                + "We don’t rent, sell or exchange your personal information.<br>"
                + "We aim to make it as simple as possible for you to control what’s visible to the public, seen by search engines, kept private, and permanently deleted.<br>"
                + "This Privacy Policy describes how Quizizz collects, uses, shares, stores and protects your personally identifiable information and how you can access, update, delete, limit, and otherwise halt the use of this information.<br>"
                + "We offer you choices regarding the collection, use, and sharing of your personal information, including the option to use services without providing personal information.<br>"
                + "We strive to support as many people as possible, including those with disabilities.<br>"
                + "If a screen reader makes this policy more accessible to you, we recommend the following browser and screen reader combinations: Chrome and ChromeVox, Safari and VoiceOver (for Mac users), and Firefox and NVDA (for Windows users)"
                + "</body></html>");
        rulesLabel.setFont(new Font("Arial", Font.PLAIN, 16));

        JScrollPane scrollPane = new JScrollPane(rulesLabel);
        scrollPane.setBounds(100, 80, 600, 300);
        add(scrollPane);

        JButton backButton = new JButton("Back");
        backButton.setBounds(350, 450, 100, 30);
        add(backButton);

        backButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new HomePage1();
            }
        });
    }
}
