import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class AdminRegisterFrame extends JFrame {
    private JTextField fullNameField;
    private JTextField emailField;
    private JTextField mobileField;
    private JPasswordField passwordField;
    private JPasswordField repeatPasswordField;
    private JTextField countryField;
    private JRadioButton femaleRadioButton;
    private JRadioButton maleRadioButton;

    public AdminRegisterFrame() {
        // Set up the frame
        setTitle("Admin Registration");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 700);
        setLocationRelativeTo(null);
        setLayout(null);

        // Add form components
        JLabel fullNameLabel = new JLabel("Full Name:");
        fullNameField = new JTextField();
        JLabel emailLabel = new JLabel("Email:");
        emailField = new JTextField();
        JLabel mobileLabel = new JLabel("Mobile:");
        mobileField = new JTextField();
        JLabel passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField();
        JLabel repeatPasswordLabel = new JLabel("Repeat Password:");
        repeatPasswordField = new JPasswordField();
        JLabel countryLabel = new JLabel("Country:");
        countryField = new JTextField();
        JLabel genderLabel = new JLabel("Gender:");
        femaleRadioButton = new JRadioButton("Female");
        maleRadioButton = new JRadioButton("Male");
        ButtonGroup genderGroup = new ButtonGroup();
        genderGroup.add(femaleRadioButton);
        genderGroup.add(maleRadioButton);
        JButton registerButton = new JButton("Register");
        JButton loginButton = new JButton("Login");

        fullNameLabel.setBounds(50, 50, 100, 30);
        fullNameField.setBounds(180, 50, 200, 30);
        emailLabel.setBounds(50, 100, 100, 30);
        emailField.setBounds(180, 100, 200, 30);
        mobileLabel.setBounds(50, 150, 100, 30);
        mobileField.setBounds(180, 150, 200, 30);
        passwordLabel.setBounds(50, 200, 100, 30);
        passwordField.setBounds(180, 200, 200, 30);
        repeatPasswordLabel.setBounds(50, 250, 130, 30);
        repeatPasswordField.setBounds(180, 250, 200, 30);
        countryLabel.setBounds(50, 300, 100, 30);
        countryField.setBounds(180, 300, 200, 30);
        genderLabel.setBounds(50, 350, 100, 30);
        femaleRadioButton.setBounds(180, 350, 80, 30);
        maleRadioButton.setBounds(270, 350, 80, 30);
        registerButton.setBounds(180, 400, 100, 30);
        loginButton.setBounds(180, 450, 100, 30);

        add(fullNameLabel);
        add(fullNameField);
        add(emailLabel);
        add(emailField);
        add(mobileLabel);
        add(mobileField);
        add(passwordLabel);
        add(passwordField);
        add(repeatPasswordLabel);
        add(repeatPasswordField);
        add(countryLabel);
        add(countryField);
        add(genderLabel);
        add(femaleRadioButton);
        add(maleRadioButton);
        add(registerButton);
        add(loginButton);
        setVisible(true);

        registerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                registerAdmin();
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the registration frame
                new AdminLoginPage(); // Open the login page
            }
        });
    }

    private void registerAdmin() {
        String fullName = fullNameField.getText();
        String email = emailField.getText();
        String mobile = mobileField.getText();
        String password = new String(passwordField.getPassword());
        String repeatPassword = new String(repeatPasswordField.getPassword());
        String country = countryField.getText();
        String gender = femaleRadioButton.isSelected() ? "Female" : "Male";

        // Perform validation
        if (fullName.isEmpty() || email.isEmpty() || mobile.isEmpty() || password.isEmpty() || repeatPassword.isEmpty() || country.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all the fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(repeatPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email address.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Insert data into the database
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/adminregisterdata", "root", "Chand@1990$%^");
            PreparedStatement statement = connection.prepareStatement("INSERT INTO Admin (Full_Name, Email, Mobile, Password, Country, Gender) VALUES (?, ?, ?, ?, ?, ?)");
            statement.setString(1, fullName);
            statement.setString(2, email);
            statement.setString(3, mobile);
            statement.setString(4, password);
            statement.setString(5, country);
            statement.setString(6, gender);
            statement.executeUpdate();
            connection.close();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error occurred while registering the admin.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this, "Admin registered successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);

        // Open the login page
        dispose(); // Close the registration frame
        new AdminLoginPage(); // Open the login page

        // Clear the form after registration
        clearForm();
    }

    private void clearForm() {
        fullNameField.setText("");
        emailField.setText("");
        mobileField.setText("");
        passwordField.setText("");
        repeatPasswordField.setText("");
        countryField.setText("");
        femaleRadioButton.setSelected(false);
        maleRadioButton.setSelected(false);
    }

    private boolean isValidEmail(String email) {
        // Perform email validation based on the provided properties
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email address is required.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (email.startsWith(".") || email.endsWith(".")) {
            JOptionPane.showMessageDialog(this, "Email address should not start or end with a period.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (email.contains("..")) {
            JOptionPane.showMessageDialog(this, "Email address should not contain consecutive periods.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (email.indexOf('@') != email.lastIndexOf('@')) {
            JOptionPane.showMessageDialog(this, "Email address should have only one '@' symbol.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (email.indexOf('@') == 0 || email.lastIndexOf('.') < email.indexOf('@')) {
            JOptionPane.showMessageDialog(this, "Invalid email address format.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }

//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(new Runnable() {
//            @Override
//            public void run() {
//                AdminRegisterFrame frame = new AdminRegisterFrame();
//                frame.setVisible(true);
//            }
//        });
    }







