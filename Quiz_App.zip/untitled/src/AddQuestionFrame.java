import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class AddQuestionFrame extends JFrame {
    JTextField subjectField;
    JTextField uniqueCodeField;
    JTextField questionField;
    JTextField option1Field;
    JTextField option2Field;
    JTextField option3Field;
    JTextField option4Field;
    JTextField correctAnswerField;
    private Connection connection;
    private int questionCounter = 1;

    public AddQuestionFrame() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(700, 700);
        setLocation(400, 200);

        JLabel heading = new JLabel("Add Question");
        heading.setBounds(250, 30, 200, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(heading);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setBounds(100, 100, 100, 30);
        add(subjectLabel);

        subjectField = new JTextField();
        subjectField.setBounds(200, 100, 200, 30);
        add(subjectField);

        JLabel uniqueCodeLabel = new JLabel("Unique Code:");
        uniqueCodeLabel.setBounds(400, 100, 100, 30);
        add(uniqueCodeLabel);

        uniqueCodeField = new JTextField();
        uniqueCodeField.setBounds(500, 100, 150, 30);
        add(uniqueCodeField);

        JLabel questionLabel = new JLabel("Question:");
        questionLabel.setBounds(100, 150, 100, 30);
        add(questionLabel);

        questionField = new JTextField();
        questionField.setBounds(200, 150, 450, 30);
        add(questionField);

        JLabel option1Label = new JLabel("Option 1:");
        option1Label.setBounds(100, 200, 100, 30);
        add(option1Label);

        option1Field = new JTextField();
        option1Field.setBounds(200, 200, 450, 30);
        add(option1Field);

        JLabel option2Label = new JLabel("Option 2:");
        option2Label.setBounds(100, 250, 100, 30);
        add(option2Label);

        option2Field = new JTextField();
        option2Field.setBounds(200, 250, 450, 30);
        add(option2Field);

        JLabel option3Label = new JLabel("Option 3:");
        option3Label.setBounds(100, 300, 100, 30);
        add(option3Label);

        option3Field = new JTextField();
        option3Field.setBounds(200, 300, 450, 30);
        add(option3Field);

        JLabel option4Label = new JLabel("Option 4:");
        option4Label.setBounds(100, 350, 100, 30);
        add(option4Label);

        option4Field = new JTextField();
        option4Field.setBounds(200, 350, 450, 30);
        add(option4Field);

        JLabel correctAnswerLabel = new JLabel("Correct Answer:");
        correctAnswerLabel.setBounds(100, 400, 120, 30);
        add(correctAnswerLabel);

        correctAnswerField = new JTextField();
        correctAnswerField.setBounds(230, 400, 200, 30);
        add(correctAnswerField);

        JButton addButton = new JButton("Add");
        addButton.setBounds(300, 500, 100, 30);
        add(addButton);

        JButton finalSubmitButton = new JButton("Final Submit");
        finalSubmitButton.setBounds(250, 550, 150, 30);
        add(finalSubmitButton);

        // Database connection
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/questionsdatabase", "root", "Chand@1990$%^");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // Action listener for the Add button
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String subject = subjectField.getText();
                String question = questionField.getText();
                String option1 = option1Field.getText();
                String option2 = option2Field.getText();
                String option3 = option3Field.getText();
                String option4 = option4Field.getText();
                String correctAnswer = correctAnswerField.getText();
                String uniqueCode = uniqueCodeField.getText();

                if (!subject.isEmpty()) {
                    try {
                        // Check if the table exists in the database
                        Statement statement = connection.createStatement();
                        ResultSet resultSet = statement.executeQuery("SHOW TABLES LIKE '" + subject + "'");
                        if (!resultSet.next()) {
                            // Create a new table with the subject name
                            statement.executeUpdate("CREATE TABLE " + subject + " (question VARCHAR(255), option1 VARCHAR(255), option2 VARCHAR(255), option3 VARCHAR(255), option4 VARCHAR(255), correctAnswer VARCHAR(255), uniqueCode VARCHAR(255))");
                        }

                        // Insert the question into the respective table
                        PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO " + subject + " (question, option1, option2, option3, option4, correctAnswer, uniqueCode) VALUES (?, ?, ?, ?, ?, ?, ?)");
                        preparedStatement.setString(1, question);
                        preparedStatement.setString(2, option1);
                        preparedStatement.setString(3, option2);
                        preparedStatement.setString(4, option3);
                        preparedStatement.setString(5, option4);
                        preparedStatement.setString(6, correctAnswer);
                        preparedStatement.setString(7, uniqueCode);
                        preparedStatement.executeUpdate();

                        // Display success message
                        JOptionPane.showMessageDialog(null, "Question " + questionCounter + " is added successfully.");
                        questionCounter++;

                        // Clear the fields
                        questionField.setText("");
                        option1Field.setText("");
                        option2Field.setText("");
                        option3Field.setText("");
                        option4Field.setText("");
                        correctAnswerField.setText("");
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        // Action listener for the Final Submit button
        finalSubmitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open the GenerateCodeFrame
                dispose(); // Close the current frame
                EventQueue.invokeLater(new Runnable() {
                    public void run() {
                        new GenerateCodeFrame();
                    }
                });
            }
        });

        setSize(700, 700);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new AddQuestionFrame();
            }
        });
    }
}
