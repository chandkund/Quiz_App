import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class ExamPage extends JFrame {
    JButton logoutButton;
    JButton javaButton, sqlButton, phpButton, cButton, pythonButton, csharpButton, rButton;
    String selectedExam;

    ExamPage() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 600);
        setLocation(600, 300);

        JLabel headerLabel = new JLabel("Select Exam");
        headerLabel.setBounds(20, 30, 200, 30);
        headerLabel.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(headerLabel);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(7, 1, 10, 10));
        buttonPanel.setBounds(250, 80, 200, 300);
        add(buttonPanel);

        javaButton = createButton("Java");
        sqlButton = createButton("SQL");
        phpButton = createButton("PHP");
        cButton = createButton("C/C++");
        pythonButton = createButton("Python");
        csharpButton = createButton("C#");
        rButton = createButton("R");

        buttonPanel.add(javaButton);
        buttonPanel.add(sqlButton);
        buttonPanel.add(phpButton);
        buttonPanel.add(cButton);
        buttonPanel.add(pythonButton);
        buttonPanel.add(csharpButton);
        buttonPanel.add(rButton);

        logoutButton = new JButton("Logout");
        logoutButton.setBounds(480, 30, 100, 30);
        add(logoutButton);

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Disconnect all connections
                // ...
                // Open the home page
                new HomePage1();
                dispose();
            }
        });
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setPreferredSize(new Dimension(150, 30));
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Set the selected exam
                selectedExam = text;
                // Open the rules frame
                new RulesFrame(selectedExam);
                dispose();
            }
        });
        return button;
    }
}



