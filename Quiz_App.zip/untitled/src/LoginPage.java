import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;


public class LoginPage extends JFrame {
    JTextField loginField;
    JPasswordField passwordField;

    LoginPage() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 400);
        setLocation(400, 200);

        JLabel heading = new JLabel("Login");
        heading.setBounds(200, 30, 100, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(heading);

        JLabel loginLabel = new JLabel("Login ID:");
        loginLabel.setBounds(100, 100, 100, 30);
        add(loginLabel);

        loginField = new JTextField();
        loginField.setBounds(200, 100, 200, 30);
        add(loginField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(100, 150, 100, 30);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(200, 150, 200, 30);
        add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.setBounds(250, 200, 100, 30);
        add(loginButton);

        JButton forgotPasswordButton = new JButton("Forgot Password");
        forgotPasswordButton.setBounds(150, 250, 150, 30);
        add(forgotPasswordButton);

        JButton registerButton = new JButton("Register");
        registerButton.setBounds(320, 250, 150, 30);
        add(registerButton);

        JButton homeButton = new JButton("Home");
        homeButton.setBounds(225, 300, 150, 30);
        add(homeButton);


        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String loginId = loginField.getText();
                String password = new String(passwordField.getPassword());
                // Perform login verification here
                // If login is successful, open the quiz page
                // Otherwise, show an error message
            }
        });


        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String loginId = loginField.getText();
                String password = new String(passwordField.getPassword());

                // Connect to the database and perform login verification
                Connection connection = null;
                try {
                    // Set up the connection parameters
                    String url = "jdbc:mysql://localhost:3306/JDBC1";
                    String username = "root";
                    String password1 = "Chand@1990$%^";

                    // Connect to the database
                    try {
                        connection = DriverManager.getConnection(url, username, password1);
                    } catch (SQLException ex) {
                        throw new RuntimeException(ex);
                    }

                    // Prepare the SQL statement
                    String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
                    PreparedStatement statement = connection.prepareStatement(sql);

                    // Set the parameter values
                    statement.setString(1, loginId);
                    statement.setString(2, password);

                    // Execute the query
                    ResultSet resultSet = statement.executeQuery();

                    if (resultSet.next()) {
                        // Login successful, open the quiz page
                        new ExamPage();
                        dispose(); // Close the login page
                    } else {
                        // Login failed, show an error message
                        JOptionPane.showMessageDialog(LoginPage.this, "Invalid login credentials", "Login Error", JOptionPane.ERROR_MESSAGE);
                    }

                    // Close the result set and statement
                    resultSet.close();
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                } finally {
                    // Close the connection
                    try {
                        if (connection != null) {
                            connection.close();
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });



        forgotPasswordButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ForgotPasswordPage();
            }
        });

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new RegisterPage();
            }
        });
        homeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new HomePage1();
            }
        });

    }
}


