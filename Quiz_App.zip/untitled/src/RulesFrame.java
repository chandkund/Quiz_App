
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class RulesFrame extends JFrame {
    JButton logoutButton, startExamButton;
    String selectedExam;

    RulesFrame(String exam) {
        selectedExam = exam;
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(700, 700);
        setLocation(600, 300);

        JLabel headingLabel = new JLabel("Instruction for Technical Test");
        headingLabel.setBounds(20, 30, 400, 30);
        headingLabel.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(headingLabel);

        JTextArea rulesTextArea = new JTextArea();
        rulesTextArea.setBounds(50, 80, 500, 300);
        rulesTextArea.setEditable(false);
        rulesTextArea.setText("1) Define the scope of the technical test, specifying the areas or skills you want to evaluate.\n"
                + "2) Prepare test materials, such as coding exercises or problem statements, that align with the defined scope.\n"
                + "3) Set up the technical environment required for the test, including any necessary software or tools.\n"
                + "4) Schedule a time for the test that works for both parties.\n"
                + "5) Communicate clear instructions to the candidate regarding the test format, rules, and expectations.\n"
                + "6) Conduct the test, ensuring the candidate has access to the necessary materials and support if needed.\n"
                + "7) Monitor the candidate's progress during the test, addressing any technical issues or questions.\n"
                + "8) Evaluate the candidate's responses or code submissions based on predetermined criteria.\n"
                + "9) Provide constructive feedback to the candidate on their performance.\n"
                + "10) Proceed with further stages of the hiring process based on the test results, such as interviews or technical discussions.");
        add(rulesTextArea);

        logoutButton = new JButton("Logout");
        logoutButton.setBounds(480, 30, 100, 30);
        add(logoutButton);

        startExamButton = new JButton("Start Exam");
        startExamButton.setBounds(250, 400, 100, 30);
        add(startExamButton);

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Disconnect all connections
                // ...
                // Open the home page
                new HomePage();
                dispose();
            }
        });

        startExamButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the respective exam page based on the selected exam
                if (selectedExam.equals("Java")) {
                    new JavaExamPage();
                } else if (selectedExam.equals("SQL")) {
                    new SQLExamPage();
                } else if (selectedExam.equals("PHP")) {
                    new PHPExamPage();
                }else if (selectedExam.equals("C/C++")) {
                    new PHPExamPage();
                }else if (selectedExam.equals("Python")) {
                    new PHPExamPage();
                }else if (selectedExam.equals("C#")) {
                    new PHPExamPage();
                }else if (selectedExam.equals("R")) {
                    new PHPExamPage();
                }
                // Add more conditionals for other exams as needed

                dispose();
            }
        });
    }
}


