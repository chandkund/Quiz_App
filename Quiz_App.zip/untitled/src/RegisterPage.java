import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

class RegisterPage extends JFrame {
    JButton registerButton;
    JButton loginButton; // New login button
    JTextField tfFullName, tfEmail, tfMobile, tfCity, tfState, tfQualification;
    JPasswordField pfPassword;

    RegisterPage() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 600);
        setLocation(600, 300);

        JLabel heading = new JLabel("Register");
        heading.setBounds(160, 30, 100, 30);
        heading.setFont(new Font("Viner Hand ITC", Font.BOLD, 24));
        add(heading);

        JLabel fullNameLabel = new JLabel("Full Name:");
        fullNameLabel.setBounds(50, 80, 100, 30);
        add(fullNameLabel);

        tfFullName = new JTextField();
        tfFullName.setBounds(150, 80, 200, 30);
        add(tfFullName);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(50, 120, 100, 30);
        add(emailLabel);

        tfEmail = new JTextField();
        tfEmail.setBounds(150, 120, 200, 30);
        add(tfEmail);

        JLabel mobileLabel = new JLabel("Mobile:");
        mobileLabel.setBounds(50, 160, 100, 30);
        add(mobileLabel);

        tfMobile = new JTextField();
        tfMobile.setBounds(150, 160, 200, 30);
        add(tfMobile);

        JLabel cityLabel = new JLabel("City:");
        cityLabel.setBounds(50, 200, 100, 30);
        add(cityLabel);

        tfCity = new JTextField();
        tfCity.setBounds(150, 200, 200, 30);
        add(tfCity);

        JLabel stateLabel = new JLabel("State:");
        stateLabel.setBounds(50, 240, 100, 30);
        add(stateLabel);

        tfState = new JTextField();
        tfState.setBounds(150, 240, 200, 30);
        add(tfState);

        JLabel qualificationLabel = new JLabel("Qualification:");
        qualificationLabel.setBounds(50, 280, 100, 30);
        add(qualificationLabel);

        tfQualification = new JTextField();
        tfQualification.setBounds(150, 280, 200, 30);
        add(tfQualification);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 320, 100, 30);
        add(passwordLabel);

        pfPassword = new JPasswordField();
        pfPassword.setBounds(150, 320, 200, 30);
        add(pfPassword);

        registerButton = new JButton("Register");
        registerButton.setBounds(150, 370, 100, 30);
        add(registerButton);

        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Get the entered data
                String fullName = tfFullName.getText();
                String email = tfEmail.getText();
                String mobile = tfMobile.getText();
                String city = tfCity.getText();
                String state = tfState.getText();
                String qualification = tfQualification.getText();
                String password = new String(pfPassword.getPassword());

                // Check if any mandatory fields are empty
                if (fullName.isEmpty() || email.isEmpty() || mobile.isEmpty() || city.isEmpty() || state.isEmpty() || qualification.isEmpty() || password.isEmpty()) {
                    JOptionPane.showMessageDialog(RegisterPage.this, "Please fill in all the fields", "Registration Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Connect to the database and store the data
                Connection connection = null;
                try {
                    // Set up the connection parameters
                    String url = "jdbc:mysql://localhost:3306/JDBC1";
                    String username = "root";
                    String password1 = "Chand@1990$%^";

                    // Connect to the database
                    connection = DriverManager.getConnection(url, username, password1);

                    // Prepare the SQL statement
                    String sql = "INSERT INTO users (full_name, email, mobile, city, state, qualification, password) VALUES (?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement statement = connection.prepareStatement(sql);

                    // Set the parameter values
                    statement.setString(1, fullName);
                    statement.setString(2, email);
                    statement.setString(3, mobile);
                    statement.setString(4, city);
                    statement.setString(5, state);
                    statement.setString(6, qualification);
                    statement.setString(7, password);

                    // Execute the statement
                    int rowsInserted = statement.executeUpdate();

                    if (rowsInserted > 0) {
                        System.out.println("Data inserted successfully!");
                    }

                    // Close the statement
                    statement.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                } finally {
                    // Close the connection
                    try {
                        if (connection != null) {
                            connection.close();
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }

                // Open the login page
                new LoginPage();
                dispose();
            }
        });

        loginButton = new JButton("Login"); // Create login button
        loginButton.setBounds(270, 370, 100, 30); // Set position and size
        add(loginButton); // Add to the frame

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Open the login page
                new LoginPage();
                dispose();
            }
        });
    }
}








