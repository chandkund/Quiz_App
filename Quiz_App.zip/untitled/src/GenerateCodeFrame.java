import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;

public class GenerateCodeFrame extends JFrame {
    private JTextField uniqueCodeField;
    private JTextField subjectField;
    private JTextField timeLimitField;
    private Connection connection;

    public GenerateCodeFrame() {
        setTitle("Generate Code");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        setSize(500, 350);

        JLabel uniqueCodeLabel = new JLabel("Enter Unique Code:");
        uniqueCodeLabel.setBounds(50, 50, 150, 30);
        add(uniqueCodeLabel);

        uniqueCodeField = new JTextField();
        uniqueCodeField.setBounds(200, 50, 200, 30);
        add(uniqueCodeField);

        JLabel subjectLabel = new JLabel("Subject:");
        subjectLabel.setBounds(50, 100, 150, 30);
        add(subjectLabel);

        subjectField = new JTextField();
        subjectField.setBounds(200, 100, 200, 30);
        add(subjectField);

        JLabel timeLimitLabel = new JLabel("Set Time Limit (in minutes):");
        timeLimitLabel.setBounds(50, 150, 150, 30);
        add(timeLimitLabel);

        timeLimitField = new JTextField();
        timeLimitField.setBounds(200, 150, 200, 30);
        add(timeLimitField);

        JButton generateButton = new JButton("Generate Exam Code");
        generateButton.setBounds(150, 200, 200, 30);
        add(generateButton);

        JButton exitButton = new JButton("Exit");
        exitButton.setBounds(50, 250, 100, 30);
        add(exitButton);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBounds(175, 250, 100, 30);
        add(logoutButton);

        JButton homeButton = new JButton("Home");
        homeButton.setBounds(300, 250, 100, 30);
        add(homeButton);
        setVisible(true);

        // Database connection
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/questionsdatabase", "root", "Chand@1990$%^");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        generateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String enteredCode = uniqueCodeField.getText();
                String enteredSubject = subjectField.getText();
                String enteredTimeLimit = timeLimitField.getText();

                if (!enteredCode.isEmpty() && !enteredSubject.isEmpty() && !enteredTimeLimit.isEmpty()) {
                    try {
                        // Check if the entered subject matches any table in the database
                        DatabaseMetaData metaData = connection.getMetaData();
                        ResultSet tables = metaData.getTables(null, null, null, new String[]{"TABLE"});

                        boolean subjectExists = false;
                        while (tables.next()) {
                            String tableName = tables.getString("TABLE_NAME");
                            if (tableName.equalsIgnoreCase(enteredSubject)) {
                                subjectExists = true;
                                break;
                            }
                        }

                        if (subjectExists) {
                            // Check if the entered code matches the uniqueCode column in the subject table
                            PreparedStatement statement = connection.prepareStatement("SELECT * FROM " + enteredSubject + " WHERE uniqueCode = ?");
                            statement.setString(1, enteredCode);
                            ResultSet resultSet = statement.executeQuery();

                            if (resultSet.next()) {
                                // Generate a random code
                                String generatedCode = generateRandomCode();

                                // Update the generated code and expiration time in the database
                                PreparedStatement updateStatement = connection.prepareStatement("UPDATE " + enteredSubject + " SET generatedCode = ?, expirationTime = ? WHERE uniqueCode = ?");
                                updateStatement.setString(1, generatedCode);

                                // Calculate the expiration time based on the entered time limit
                                long currentTime = System.currentTimeMillis();
                                long timeLimitMinutes = Long.parseLong(enteredTimeLimit);
                                long expirationTimeMillis = currentTime + (timeLimitMinutes * 60 * 1000);
                                Timestamp expirationTimestamp = new Timestamp(expirationTimeMillis);
                                updateStatement.setTimestamp(2, expirationTimestamp);

                                updateStatement.setString(3, enteredCode);
                                updateStatement.executeUpdate();

                                StringBuilder quizCodeBuilder = new StringBuilder();
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss a");
                                String formattedExpirationTime = dateFormat.format(expirationTimestamp);

                                quizCodeBuilder.append("Quiz Code\n");
                                quizCodeBuilder.append("Generated Code: ").append(generatedCode).append("\n");
                                quizCodeBuilder.append("Expiration Time: ").append(formattedExpirationTime).append("\n");

                                String quizCode = quizCodeBuilder.toString();
                                JOptionPane.showMessageDialog(GenerateCodeFrame.this, quizCode, "Generated Quiz Code", JOptionPane.INFORMATION_MESSAGE);
                            } else {
                                JOptionPane.showMessageDialog(GenerateCodeFrame.this, "Invalid Unique Code", "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        } else {
                            JOptionPane.showMessageDialog(GenerateCodeFrame.this, "Invalid Subject", "Error", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                } else {
                    JOptionPane.showMessageDialog(GenerateCodeFrame.this, "Please enter Unique Code, Subject, and Time Limit", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        exitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(GenerateCodeFrame.this, "Are you sure you want to exit?", "Exit Confirmation", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(GenerateCodeFrame.this, "Are you sure you want to logout?", "Logout Confirmation", JOptionPane.YES_NO_OPTION);

                if (option == JOptionPane.YES_OPTION) {
                    // Perform logout actions here
                    dispose(); // Close the GenerateCodeFrame
                    // Open the login frame or any other appropriate frame
                    new AdminLoginPage();
                }
            }
        });

        homeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Perform home actions here
                dispose(); // Close the GenerateCodeFrame
                // Open the home frame or any other appropriate frame
                new HomePage();
            }
        });
    }

    private String generateRandomCode() {
        StringBuilder codeBuilder = new StringBuilder();
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        int codeLength = (int) (Math.random() * 10) + 5; // Random length between 5 and 14

        for (int i = 0; i < codeLength; i++) {
            int randomIndex = (int) (Math.random() * characters.length());
            codeBuilder.append(characters.charAt(randomIndex));
        }

        return codeBuilder.toString();
    }
}
