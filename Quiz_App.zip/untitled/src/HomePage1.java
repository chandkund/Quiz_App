import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class HomePage1 extends JFrame {

    private Image backgroundImage;

    public HomePage1() {
        setTitle("Quiz Home Page");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        // Load the background image
        backgroundImage = new ImageIcon(ClassLoader.getSystemResource("icon/quizz12.jpg")).getImage();

        // Create a custom JPanel to serve as the content pane
        JPanel contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                // Draw the background image
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        // Set the layout to null for absolute positioning
        contentPane.setLayout(null);

        // Add your components and set their positions using setBounds()
        // ...

        // Logo
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/Quizz23.jpg"));
        Image i2 = i1.getImage().getScaledInstance(95, 95, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 90, 90);
        contentPane.add(image);

        // Upper right buttons (Login, SignUp, Enter Quiz Code)
        JPanel upperRightPanel = new JPanel();
        upperRightPanel.setBounds(500, 20, 250, 100);
        upperRightPanel.setLayout(new BoxLayout(upperRightPanel, BoxLayout.X_AXIS));

        JButton loginButton = new JButton("Login");
        upperRightPanel.add(loginButton);

        JButton signUpButton = new JButton("Sign Up");
        upperRightPanel.add(signUpButton);

        JButton enterCodeButton = new JButton("Enter Quiz Code");
        upperRightPanel.add(enterCodeButton);

        contentPane.add(upperRightPanel);

        // "Quizz" title
        JLabel quizTitleLabel = new JLabel("QUIZZ");
        quizTitleLabel.setFont(new Font("Arial", Font.BOLD, 27));
        quizTitleLabel.setBounds(300, 20, 100, 30);
        contentPane.add(quizTitleLabel);

        // "Create Quiz" button
        JButton createQuizButton = new JButton("Create Quiz");
        createQuizButton.setBounds(320, 440, 180, 30);
        contentPane.add(createQuizButton);

        // Image
        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icon/Quizlogo.jpeg"));
        Image i5 = i4.getImage().getScaledInstance(95, 95, Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i2);
        JLabel image1 = new JLabel(i3);
        image1.setBounds(0, 0, 90, 90);
        contentPane.add(image1);

        // Bottom buttons (About Us, Terms of Use, Privacy Policy)
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBounds(0, 500, 800, 40);
        bottomPanel.setLayout(new FlowLayout(FlowLayout.CENTER));

        JButton aboutUsButton = new JButton("About Us");
        bottomPanel.add(aboutUsButton);

        JButton termsOfUseButton = new JButton("Terms of Use");
        bottomPanel.add(termsOfUseButton);

        JButton privacyPolicyButton = new JButton("Privacy Policy");
        bottomPanel.add(privacyPolicyButton);

        contentPane.add(bottomPanel);

        // ActionListener for buttons
        enterCodeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new EnterQuizCodeFrame();
                dispose();
            }
        });

        createQuizButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AdminRegisterFrame();
                dispose();
            }
        });

        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new LoginPage();
                dispose();
            }
        });

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new RegisterPage();
                dispose();
            }
        });

        aboutUsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AboutUsPage();
                dispose();
            }
        });

        termsOfUseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new TermOfUsePage();
                dispose();
            }
        });

        privacyPolicyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new PrivacyPolicyFrame();
                dispose();
            }
        });

        // Set the content pane of the frame to the custom panel
        setContentPane(contentPane);

        // Make the frame visible
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(HomePage1::new);
    }
}
