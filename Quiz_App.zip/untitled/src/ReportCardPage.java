import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

class ReportCardPage extends JFrame {
    private String mobileNumber;

    ReportCardPage(int score ) {
        this.mobileNumber = mobileNumber;

        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setVisible(true);
        setSize(600, 600);
        setLocation(600, 300);

        JLabel reportLabel = new JLabel("Report Card");
        reportLabel.setBounds(200, 20, 200, 30);
        reportLabel.setFont(new Font("Arial", Font.BOLD, 20));
        add(reportLabel);

        JLabel nameLabel = new JLabel("Name: " + getFullNameFromDatabase());
        nameLabel.setBounds(250, 70, 200, 30);
        add(nameLabel);

        JLabel scoreLabel = new JLabel("Score: " + score);
        scoreLabel.setBounds(250, 100, 100, 30);
        add(scoreLabel);

        JLabel messageLabel = new JLabel("Quiz completed. Thank you!");
        messageLabel.setBounds(180, 150, 300, 30);
        messageLabel.setFont(new Font("Arial", Font.BOLD, 16));
        add(messageLabel);

        JButton exitButton = new JButton("Exit");
        exitButton.setBounds(250, 200, 100, 30);
        exitButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose(); // Close the report card frame
                new ExamPage(); // Open the exam page
            }
        });
        add(exitButton);
    }

    private String getFullNameFromDatabase() {
        String fullName = "";
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/JDBC1", "root", "Chand@1990$%^");
            PreparedStatement statement = connection.prepareStatement("SELECT Full_name FROM users WHERE Mobile = ?");
            statement.setString(1, mobileNumber);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                fullName = resultSet.getString("Full_name");
            }

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return fullName;
    }
}













