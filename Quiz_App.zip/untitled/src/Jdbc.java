import java.sql.*;
public class Jdbc {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // Register the driver class.
        Class.forName("com.mysql.jdbc.Driver");

        // Create a connection.
        String url = "jdbc:mysql://localhost:3306/Register";
        String username = "root";
        String password = "Chand@1990$%^";
        Connection connection = DriverManager.getConnection(url, username, password);

        // Create a statement.
        Statement statement = connection.createStatement();

        // Execute a query.
        String query = "INSERT INTO users (Full_Name, Email, Mobile, City, State, Qualification, Password) VALUES ('John Doe', 'johndoe@gmail.com', '1234567890', 'New York', 'NY', 'MBA', 'password')";
        int rowsAffected = statement.executeUpdate(query);

        // Print the results.
        if (rowsAffected > 0) {
            System.out.println("A new record has been inserted into the users table.");
        } else {
            System.out.println("No records were inserted into the users table.");
        }

        // Close the connection.
        connection.close();
    }
}


